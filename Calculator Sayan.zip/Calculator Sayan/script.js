let currentInput = '';
let operation = null;
let previousInput = null;

function appendNumber(number) {
    currentInput += number;
    updateResult(currentInput);
}

function setOperation(op) {
    if (currentInput === '') return;
    if (operation !== null) calculate();
    operation = op;
    previousInput = currentInput;
    currentInput = '';
}

function calculate() {
    if (operation === null || currentInput === '' || previousInput === null) return;
    let result;
    const prev = parseFloat(previousInput);
    const curr = parseFloat(currentInput);

    switch (operation) {
        case '+':
            result = prev + curr;
            break;
        case '-':
            result = prev - curr;
            break;
        case '*':
            result = prev * curr;
            break;
        case '/':
            result = prev / curr;
            break;
        default:
            return;
    }

    updateResult(result);
    currentInput = result.toString();
    operation = null;
    previousInput = null;
}

function clearResult() {
    currentInput = '';
    operation = null;
    previousInput = null;
    updateResult('');
}

function updateResult(value) {
    document.getElementById('result').value = value;
}